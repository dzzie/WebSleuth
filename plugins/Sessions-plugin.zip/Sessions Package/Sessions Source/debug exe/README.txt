

everytime you switch between this project that outputs an exe and the
one in the parent directory that outputs a dll you are going to loose
reference to the cmndlg.ctl usercontrol and it is going say error this
and error that and replace it with a picture box...

i have no idea why and it sucks..but it is a super easy fix..when you
go back and forth each time..just delete the picture box it created 
and then drop a new instance of the cmsdlg.ctl from the toolbox onto
the main form anywhere...it was meant to use its default name (de sure
to remove picture box first so it gets its default name though!)

